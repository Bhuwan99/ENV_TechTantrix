<?php 
$servername='localhost';
$username='root';
$password='';
$db='mediclean';

$connection= mysqli_connect($servername,$username,$password,$db);

?>